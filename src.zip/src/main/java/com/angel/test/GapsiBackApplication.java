package com.angel.test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GapsiBackApplication {

    public static void main(String[] args) {
        SpringApplication.run(GapsiBackApplication.class, args);
    }

}

